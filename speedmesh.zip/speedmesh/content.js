// === КОНФИГУРАЦИЯ ===
const SELECTORS = {
    noiseBlocks: ['.banner-container', '.ad-wrapper', 'div[class*="banner"]', '.news-block-sidebar'],
    footer: 'footer',
    studentName: '.student-fio, .header__profile-name'
};

let customRules = [];
let isPickingMode = false;
let hoveredElement = null;
let selectedElements = new Set(); 

// === ИНИЦИАЛИЗАЦИЯ ===
function init() {
    chrome.storage.sync.get(['disableAnimations', 'hideAds', 'hideFooter', 'highlightGrades', 'highlightStudent', 'customRules'], (settings) => {
        customRules = settings.customRules || [];
        applySettings(settings);
    });
}

function applySettings(settings) {
    if (!settings) return;
    
    // 1. Ускорение работы (Новая функция)
    toggleAnimations(settings.disableAnimations);

    // 2. Сброс старых стилей
    resetCustomStyles();

    // 3. Формирование CSS
    let cssAccumulator = '';

    if (settings.hideAds) SELECTORS.noiseBlocks.forEach(sel => cssAccumulator += `${sel} { display: none !important; }\n`);
    if (settings.hideFooter) cssAccumulator += `${SELECTORS.footer} { display: none !important; }\n`;
    
    if (settings.customRules) {
        settings.customRules.forEach(rule => {
            if (rule.action === 'hide') {
                cssAccumulator += `${rule.selector} { display: none !important; }\n`;
            } else if (rule.action === 'color') {
                cssAccumulator += `${rule.selector} { background-color: ${rule.value} !important; background-image: none !important; }\n`;
            }
        });
    }
    
    injectStyles(cssAccumulator);

    // 4. JS обработка (Оценки)
    if (settings.highlightGrades || settings.highlightStudent) processTextElements(settings);
}


// === НОВАЯ ФУНКЦИЯ УСКОРЕНИЯ ===
function toggleAnimations(enable) {
    const styleId = 'mesh-performance-style';
    const existing = document.getElementById(styleId);

    if (enable) {
        if (!existing) {
            const style = document.createElement('style');
            style.id = styleId;
            // Отключаем transition, animation и плавный скролл
            style.innerHTML = `
                *, *::before, *::after {
                    transition: none !important;
                    animation: none !important;
                    scroll-behavior: auto !important;
                }
            `;
            document.head.appendChild(style);
        }
    } else {
        if (existing) {
            existing.remove();
        }
    }
}

function injectStyles(css) {
    const styleId = 'mesh-main-style';
    let styleTag = document.getElementById(styleId);
    if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = styleId;
        document.head.appendChild(styleTag);
    }
    styleTag.innerHTML = css;
}

function resetCustomStyles() {
    const styleTag = document.getElementById('mesh-main-style');
    if (styleTag) styleTag.innerHTML = '';
}

// === ПАНЕЛЬ УПРАВЛЕНИЯ (Floating UI) ===
function createFloatingPanel() {
    if (document.getElementById('mesh-float-panel')) return;
    const panel = document.createElement('div');
    panel.id = 'mesh-float-panel';
    panel.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 5px; color:#333;">Режим выбора</div>
        <div style="font-size: 12px; margin-bottom: 10px; color:#555;">Выбрано блоков: <b id="mesh-sel-count">0</b></div>
        <div style="display: flex; gap: 8px;">
            <button id="mesh-btn-config" style="background: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: bold;">Настроить</button>
            <button id="mesh-btn-cancel" style="background: #6c757d; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer;">Отмена</button>
        </div>
    `;
    panel.style.cssText = `
        position: fixed; bottom: 20px; right: 20px; background: white; padding: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.25); z-index: 2147483647; border-radius: 8px;
        font-family: sans-serif; border-left: 5px solid #dc3545;
    `;
    document.body.appendChild(panel);

    document.getElementById('mesh-btn-config').addEventListener('click', showActionModal);
    document.getElementById('mesh-btn-cancel').addEventListener('click', stopPickingMode);
}

function updateFloatCounter() {
    const el = document.getElementById('mesh-sel-count');
    if (el) el.innerText = selectedElements.size;
}

// === ЛОГИКА ВЫБОРА ===
function startPickingMode() {
    isPickingMode = true;
    selectedElements.clear();
    createFloatingPanel();
    
    const style = document.createElement('style');
    style.id = 'mesh-picker-css';
    style.innerHTML = `
        .mesh-hover-target { outline: 2px dashed #dc3545 !important; background: rgba(220, 53, 69, 0.1) !important; cursor: pointer !important; }
        .mesh-selected-target { outline: 3px solid #dc3545 !important; background: rgba(220, 53, 69, 0.25) !important; box-shadow: 0 0 10px rgba(220, 53, 69, 0.4) !important; }
    `;
    document.head.appendChild(style);
}

function stopPickingMode() {
    isPickingMode = false;
    selectedElements.forEach(el => el.classList.remove('mesh-selected-target'));
    selectedElements.clear();
    const p = document.getElementById('mesh-float-panel'); if(p) p.remove();
    const m = document.getElementById('mesh-action-modal'); if(m) m.remove();
    const s = document.getElementById('mesh-picker-css'); if(s) s.remove();
    if (hoveredElement) hoveredElement.classList.remove('mesh-hover-target');
}

document.addEventListener('mouseover', (e) => {
    if (!isPickingMode) return;
    if (e.target.closest('#mesh-float-panel') || e.target.closest('#mesh-action-modal')) return;
    e.preventDefault(); e.stopPropagation();
    if (hoveredElement && hoveredElement !== e.target) hoveredElement.classList.remove('mesh-hover-target');
    hoveredElement = e.target;
    if (!selectedElements.has(hoveredElement)) hoveredElement.classList.add('mesh-hover-target');
}, true);

document.addEventListener('click', (e) => {
    if (!isPickingMode) return;
    if (e.target.closest('#mesh-float-panel') || e.target.closest('#mesh-action-modal')) return;
    e.preventDefault(); e.stopPropagation();
    const target = e.target;
    if (selectedElements.has(target)) {
        selectedElements.delete(target);
        target.classList.remove('mesh-selected-target');
        target.classList.add('mesh-hover-target');
    } else {
        selectedElements.add(target);
        target.classList.remove('mesh-hover-target');
        target.classList.add('mesh-selected-target');
    }
    updateFloatCounter();
}, true);

// === МОДАЛЬНОЕ ОКНО ===
function showActionModal() {
    if (selectedElements.size === 0) { alert("Сначала выберите хотя бы один блок!"); return; }
    const old = document.getElementById('mesh-action-modal'); if (old) old.remove();
    const modal = document.createElement('div');
    modal.id = 'mesh-action-modal';
    modal.innerHTML = `
        <div style="font-weight:bold; margin-bottom:8px; font-size:14px; color:#333;">Настройка (${selectedElements.size} блоков)</div>
        <div style="display:flex; flex-direction:column; gap:8px;">
            <button id="mesh-act-hide" style="background:#dc3545; color:white; border:none; padding:10px; border-radius:4px; cursor:pointer;">👁️ Скрыть всё</button>
            <div style="display:flex; align-items:center; gap:5px; background:#f0f0f0; padding:5px; border-radius:4px;">
                <input type="color" id="mesh-act-color-input" value="#ff0000" style="border:none; width:30px; height:30px; cursor:pointer; background:none;">
                <span style="font-size:12px; color:#333;">Покрасить всё</span>
            </div>
            <div style="display:flex; gap:5px; margin-top:5px;">
                <button id="mesh-act-save" style="flex:1; background:#28a745; color:white; border:none; padding:8px; border-radius:4px; cursor:pointer; font-weight:bold;">Сохранить</button>
                <button id="mesh-act-close" style="flex:1; background:#6c757d; color:white; border:none; padding:8px; border-radius:4px; cursor:pointer;">Закрыть</button>
            </div>
        </div>
    `;
    modal.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        width: 220px; background: white; padding: 20px; border-radius: 8px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.5); z-index: 2147483647;
        font-family: sans-serif; border: 1px solid #ccc;
    `;
    document.body.appendChild(modal);

    let pendingAction = null;
    let pendingValue = null;

    document.getElementById('mesh-act-hide').addEventListener('click', () => {
        selectedElements.forEach(el => { el.style.display = 'none'; el.style.backgroundColor = ''; });
        pendingAction = 'hide';
    });

    document.getElementById('mesh-act-color-input').addEventListener('input', (e) => {
        pendingAction = 'color'; pendingValue = e.target.value;
        selectedElements.forEach(el => { el.style.display = ''; el.style.backgroundColor = pendingValue; el.style.backgroundImage = 'none'; });
    });

    document.getElementById('mesh-act-save').addEventListener('click', () => {
        if (!pendingAction) return alert('Выберите действие!');
        const newRules = [];
        selectedElements.forEach(el => {
            newRules.push({ selector: generateSelector(el), action: pendingAction, value: pendingValue });
        });
        const updatedRules = [...customRules, ...newRules];
        customRules = updatedRules;
        chrome.storage.sync.set({customRules: updatedRules}, () => {
            stopPickingMode(); resetCustomStyles(); applySettings({customRules: updatedRules});
        });
    });

    document.getElementById('mesh-act-close').addEventListener('click', () => {
        selectedElements.forEach(el => { el.style.display = ''; el.style.backgroundColor = ''; });
        modal.remove();
    });
}

// === УТИЛИТЫ ===
function generateSelector(el) {
    if (el.id) return '#' + el.id;
    if (el.className && typeof el.className === 'string') {
        const classes = el.className.trim().split(/\s+/).filter(c => !c.startsWith('mesh-') && !c.includes('hover') && !c.includes('active'));
        if (classes.length > 0) return el.tagName.toLowerCase() + '.' + classes.join('.');
    }
    let path = [], node = el;
    while (node.nodeType === Node.ELEMENT_NODE) {
        let sel = node.nodeName.toLowerCase();
        if (node.id) { sel += '#' + node.id; path.unshift(sel); break; }
        else {
            let sib = node, nth = 1;
            while (sib = sib.previousElementSibling) { if (sib.nodeName.toLowerCase() == sel) nth++; }
            if (nth != 1) sel += ":nth-of-type("+nth+")";
        }
        path.unshift(sel); node = node.parentNode;
    }
    return path.join(" > ");
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "updateSettings") applySettings(request.settings);
    if (request.action === "startPicking") startPickingMode();
    if (request.action === "refreshRules") { customRules = request.rules; location.reload(); }
});

const observer = new MutationObserver(() => {
    // Внимание: для производительности мы не перезаписываем стили анимации тут,
    // так как они глобальны и внедряются один раз в <head>.
    // А вот остальные настройки (оценки) надо проверять.
    chrome.storage.sync.get(['highlightGrades', 'highlightStudent'], (s) => {
        if(s.highlightGrades || s.highlightStudent) processTextElements(s);
    });
});
observer.observe(document.body, { childList: true, subtree: true });

function processTextElements(settings) {
    const finalGradeRegex = /^[2-5],\d{2}$/;
    document.querySelectorAll('span, div, p, td').forEach(el => {
        if (el.offsetParent === null) return;
        const text = el.innerText.trim();
        if (settings.highlightGrades && finalGradeRegex.test(text)) {
           const val = parseFloat(text.replace(',', '.'));
           el.style.cssText += 'font-weight:normal; padding:0 2px; border-radius:3px; color:#fff;';
           if(val>=4.5) el.style.backgroundColor='#28a745';
           else if(val>=3.5) el.style.backgroundColor='#17a2b8';
           else if(val>=2.5) el.style.backgroundColor='#ffc107';
           else el.style.backgroundColor='#dc3545';
        }
        if (settings.highlightStudent && el.matches(SELECTORS.studentName)) {
            el.style.border = '2px solid #007bff'; el.style.backgroundColor = '#e7f1ff';
        }
    });
}

init();