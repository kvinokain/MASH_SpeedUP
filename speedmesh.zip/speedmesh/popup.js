document.addEventListener('DOMContentLoaded', () => {
    const els = {
        disableAnimations: document.getElementById('disableAnimations'), // Новый элемент
        hideAds: document.getElementById('hideAds'),
        hideFooter: document.getElementById('hideFooter'),
        highlightGrades: document.getElementById('highlightGrades'),
        highlightStudent: document.getElementById('highlightStudent'),
        rulesList: document.getElementById('rulesList'),
        status: document.getElementById('status')
    };

    // Загрузка
    chrome.storage.sync.get(['disableAnimations', 'hideAds', 'hideFooter', 'highlightGrades', 'highlightStudent', 'customRules'], (data) => {
        els.disableAnimations.checked = data.disableAnimations || false;
        els.hideAds.checked = data.hideAds || false;
        els.hideFooter.checked = data.hideFooter || false;
        els.highlightGrades.checked = data.highlightGrades || false;
        els.highlightStudent.checked = data.highlightStudent || false;
        renderRulesList(data.customRules || []);
    });

    // Сохранение
    document.getElementById('saveBtn').addEventListener('click', () => {
        const settings = {
            disableAnimations: els.disableAnimations.checked, // Сохраняем новую настройку
            hideAds: els.hideAds.checked,
            hideFooter: els.hideFooter.checked,
            highlightGrades: els.highlightGrades.checked,
            highlightStudent: els.highlightStudent.checked
        };
        chrome.storage.sync.set(settings, () => {
            els.status.innerText = 'Сохранено!';
            setTimeout(() => els.status.innerText = '', 1500);
            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, {action: "updateSettings", settings: settings});
            });
        });
    });

    // Остальной код без изменений
    document.getElementById('pickBtn').addEventListener('click', () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, {action: "startPicking"});
            window.close();
        });
    });

    function renderRulesList(rules) {
        els.rulesList.innerHTML = '';
        if (!rules || rules.length === 0) {
            els.rulesList.innerHTML = '<li style="padding:10px; color:#999; text-align:center; font-size:11px;">Нет правил</li>'; return;
        }
        rules.forEach((rule, index) => {
            const li = document.createElement('li');
            li.className = 'rule-item';
            let typeBadge = rule.action === 'hide' ? '<span class="rule-type type-hide">СКРЫТ</span>' : '<span class="rule-type type-color" style="background:'+rule.value+'">ЦВЕТ</span>';
            let name = rule.selector.split('.').pop() || rule.selector;
            if(name.length > 20) name = name.substring(0,20) + '...';
            li.innerHTML = `<div>${typeBadge}<span class="rule-name" title="${rule.selector}">${name}</span></div><span class="delete-rule" data-idx="${index}" title="Удалить">✖</span>`;
            els.rulesList.appendChild(li);
        });
        document.querySelectorAll('.delete-rule').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = e.target.getAttribute('data-idx');
                rules.splice(idx, 1);
                chrome.storage.sync.set({customRules: rules}, () => {
                    renderRulesList(rules);
                    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                        chrome.tabs.sendMessage(tabs[0].id, {action: "refreshRules", rules: rules});
                    });
                });
            });
        });
    }
});