const fields = [
    'autoGrader', 'focusMode', 'highlightGrades', 'highlightStudent', 'calcAttendance',
    'duplicateFinder', 'hideAds', 'disableAnimations', 'antiLogout', 'formSaver', 'batchClick'
];

document.addEventListener('DOMContentLoaded', () => {
    // Load settings
    chrome.storage.sync.get(null, (data) => {
        fields.forEach(id => {
            const el = document.getElementById(id);
            if (el) { el.checked = data[id] === undefined ? false : data[id]; }
        });
        // Default True values for some
        if (data.highlightGrades === undefined) document.getElementById('highlightGrades').checked = true;
        if (data.highlightStudent === undefined) document.getElementById('highlightStudent').checked = true;
        if (data.calcAttendance === undefined) document.getElementById('calcAttendance').checked = true;
    });

    // Save settings
    document.getElementById('saveBtn').addEventListener('click', () => {
        const settings = {};
        fields.forEach(id => { settings[id] = document.getElementById(id).checked; });
        chrome.storage.sync.set(settings, () => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0] && tabs[0].url.includes('mos.ru')) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: "updateSettings", settings }).catch(() => { });
                    chrome.tabs.reload(tabs[0].id);
                }
                window.close();
            });
        });
    });

    // Handle Buttons
    document.getElementById('pickBtn').addEventListener('click', () => { sendMessage({ action: "startPicking" }); window.close(); });
    document.getElementById('exportMenuBtn').addEventListener('click', () => { sendMessage({ action: "startExport" }); window.close(); });

    function sendMessage(msg) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, msg).catch(() => { });
        });
    }
});