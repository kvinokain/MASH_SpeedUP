// MESH Autonomous v79.0 — Supervised API Buffer Workflow (Column -> Student -> Buffer -> API)

// 1. Внедрение перехватчика API-запросов (DB Gathering)
try {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('interceptor.js');
    s.onload = function () { this.remove(); };
    (document.head || document.documentElement).appendChild(s);
} catch (e) { }

const SELECTORS = {
    tableRows: 'tr, [role="row"], .Dnevnik-grid-row',
    noise: ['.banner-container', '.ad-wrapper', 'div[class*="banner"]', '.news-block-sidebar', 'footer', '[aria-label="Реклама"]']
};
console.log('MESH Content Script Loaded (No Blur + 0 Grade):', new Date().toISOString());

let extSettings = {};
let isRobotActive = false;
let abortRobot = false;
let isPaused = false; // New flag for Soft Cancel
let localDatabase = { ids: {}, names: {} };
let tooltipElement = null;
let selectedColumns = []; // [{x, width}]
let selectedStudents = new Set(); // Stores cleanNameKey of selected students
let gradeBuffer = [];     // [{studentName, grade, cell, applied, error, skipped}]
let apiErrorLogs = [];    // Global error log storage

// State for tools
let isPicking = false;
let selectedSet = new Set();
let hoveredEl = null;

// ==========================================
// 0. INIT & LISTENERS
// ==========================================

window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'MESH_DB_UPDATE') {
        Object.assign(localDatabase.ids, e.data.db.ids);
        Object.assign(localDatabase.names, e.data.db.names);
    }
    if (e.data && e.data.type === 'MESH_DEBUG_SPY') {
        const dump = JSON.stringify(e.data, null, 2);
        console.log("🕵️ SPY DATA RECEIVED", e.data);

        // Create a floating button to show the logs
        let btn = document.getElementById('mesh-spy-btn');
        if (!btn) {
            btn = document.createElement('button');
            btn.id = 'mesh-spy-btn';
            btn.innerText = "🕵️ SPY DATA (Click to Copy)";
            btn.style.cssText = "position:fixed; top:60px; right:10px; z-index:9999999; padding:15px; background:#8e44ad; color:white; border:2px solid #fff; border-radius:8px; cursor:pointer; font-weight:bold; box-shadow:0 5px 15px rgba(0,0,0,0.3);";
            btn.onclick = () => {
                prompt("Скопируйте данные шпиона (Ctrl+C):", dump);
            };
            document.body.appendChild(btn);
        } else {
            // Update the dump
            btn.onclick = () => prompt("Скопируйте данные шпиона (Ctrl+C):", dump);
            btn.innerText = "🕵️ SPY DATA (Updated!)";
            setTimeout(() => btn.innerText = "🕵️ SPY DATA (Click to Copy)", 2000);
        }
    }
});

let initInterval = setInterval(() => {
    if (document.body) {
        clearInterval(initInterval);
        chrome.storage.sync.get(null, (data) => {
            extSettings = data || {};
            applyAllSettings();
            initTooltip();

            // Если включен режим авто-оценок, запускаем Воркфлоу (если еще не запущен)
            setInterval(() => {
                if (extSettings.autoGrader && !isPaused && !isRobotActive && !document.getElementById('mesh-col-picker-bar') && !document.getElementById('mesh-student-selector') && !document.getElementById('mesh-buffer-panel')) {
                    const hasEmptyCells = document.querySelector(SELECTORS.tableRows);
                    if (hasEmptyCells) startGradingFlow();
                }
                // Regular visual updates
                if (!isRobotActive) analyzeTableVisuals();
            }, 1000);

            document.addEventListener('mouseover', handleTooltipShow);
            document.addEventListener('mouseout', handleTooltipHide);
        });
    }
}, 50);

chrome.runtime.onMessage.addListener((req) => {
    if (req.action === "updateSettings") { extSettings = req.settings; applyAllSettings(); }
    if (req.action === "startPicking") startPicking();
    if (req.action === "startExport") startExport();
});

function applyAllSettings() {
    injectStyles();

    // Ads
    const noiseStyle = document.getElementById('mesh-noise-style');
    if (extSettings.hideAds) {
        if (!noiseStyle) {
            const css = SELECTORS.noise.map(s => `${s} { display: none !important; }`).join('\n');
            injectStyle('mesh-noise-style', css);
        }
    } else if (noiseStyle) noiseStyle.remove();

    // Animations
    const animStyle = document.getElementById('mesh-anim-style');
    if (extSettings.disableAnimations) {
        if (!animStyle) injectStyle('mesh-anim-style', `*, *::before, *::after { transition: none !important; animation: none !important; scroll-behavior: auto !important; }`);
    } else if (animStyle) animStyle.remove();

    // Anti-Logout
    if (extSettings.antiLogout) {
        if (!window._meshPing) window._meshPing = setInterval(() => fetch(window.location.href, { method: 'HEAD' }).catch(() => { }), 270000);
    } else if (window._meshPing) { clearInterval(window._meshPing); window._meshPing = null; }

    // Batch Click
    document.removeEventListener('click', handleBatchClick);
    if (extSettings.batchClick) document.addEventListener('click', handleBatchClick);

    // Form Saver
    document.removeEventListener('input', handleFormInput);
    if (extSettings.formSaver) { document.addEventListener('input', handleFormInput); restoreForms(); }
}

function injectStyles() {
    if (document.getElementById('mesh-injected-styles')) return;
    const style = document.createElement('style');
    style.id = 'mesh-injected-styles';
    style.innerHTML = `
        .mesh-phantom { color: #95a5a6; font-style: italic; pointer-events: none; opacity: 0.8; font-weight: bold; }
        .mesh-dimmed-row { opacity: 0.15 !important; filter: grayscale(1) !important; transition: all 0.3s ease !important; }
        .mesh-dimmed-row:hover { opacity: 1 !important; filter: none !important; z-index: 10; position: relative; }
        .api-success-badge { background:#27ae60; color:#fff; border-radius:4px; padding:3px 6px; font-weight:bold; font-size:11px; display:inline-block; }
        .api-error-badge { background:#e74c3c; color:#fff; border-radius:4px; padding:3px 6px; font-weight:bold; font-size:11px; display:inline-block; cursor:help;}
        #mesh-custom-tooltip { position: fixed; background: rgba(44, 62, 80, 0.95); color: white; padding: 8px 12px; border-radius: 6px; font-size: 13px; z-index: 999999; pointer-events: none; display: none; box-shadow: 0 4px 15px rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); line-height: 1.4; }
        
        /* Modals Common Styles */
        .mesh-modal-overlay { position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999990; }
        .mesh-modal-panel { position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); background:#1a1a2e; color:#eee; border-radius:16px; box-shadow:0 20px 60px rgba(0,0,0,0.6); z-index:9999991; font-family:'Segoe UI',sans-serif; display:flex; flex-direction:column; overflow:hidden; border:1px solid rgba(255,255,255,0.1); }
        .mesh-modal-header { padding:18px 20px; background:linear-gradient(135deg,#8e44ad,#6c3483); border-radius:16px 16px 0 0; }
        .mesh-modal-content { flex:1; overflow-y:auto; padding:10px 15px; }
        .mesh-modal-footer { padding:12px 15px; border-top:1px solid rgba(255,255,255,0.1); display:flex; gap:10px; }
        
        .mesh-list-row { display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:8px; margin-bottom:4px; background:rgba(255,255,255,0.05); transition:background 0.2s; }
        .mesh-list-row:hover { background:rgba(255,255,255,0.1); }
        .mesh-buf-input { width:42px; text-align:center; padding:4px; border:1px solid #555; border-radius:6px; background:#2a2a3e; color:#f1c40f; font-size:15px; font-weight:bold; outline:none; }
    `;
    document.head.appendChild(style);
}

function injectStyle(id, content) {
    let style = document.getElementById(id);
    if (!style) { style = document.createElement('style'); style.id = id; document.head.appendChild(style); }
    style.innerHTML = content;
}

// ==========================================
// 1. VISUAL ANALYTICS (Passive)
// ==========================================

function analyzeTableVisuals() {
    const rows = document.querySelectorAll(SELECTORS.tableRows);
    if (rows.length === 0) return;

    rows.forEach(row => {
        if (row.getBoundingClientRect().height === 0) return;

        let nameEl = null; let fAvg = 0; let hasGrade = false; let absCount = 0; let marksCount = 0;

        row.querySelectorAll('span, div, p, td').forEach(cell => {
            // ... parsing logic same as before ...
            if (cell.children.length > 0 && cell.tagName !== 'TD') return;
            const text = cell.innerText ? cell.innerText.trim() : "";
            if (!nameEl && text.split(' ').length >= 2 && /^[А-ЯЁ]/.test(text) && !text.includes('Ср')) { nameEl = cell; }
            if (/^[2-5][.,]\d{2}$/.test(text)) {
                fAvg = parseFloat(text.replace(',', '.'));
                if (extSettings.highlightGrades) {
                    cell.style.color = '#fff'; cell.style.borderRadius = '3px'; cell.style.fontWeight = 'bold'; cell.style.padding = '0 4px';
                    if (fAvg >= 4.5) cell.style.backgroundColor = '#27ae60'; else if (fAvg >= 3.5) cell.style.backgroundColor = '#3498db'; else if (fAvg >= 2.5) cell.style.backgroundColor = '#f39c12'; else cell.style.backgroundColor = '#c0392b';
                }
            }
            if (/^[1-5нh]$/i.test(text) && !cell.closest('sub')) hasGrade = true;
            if (text.length <= 5 && !/^[2-5][.,]\d{2}$/.test(text)) {
                text.toLowerCase().split(/\s+/).forEach((t) => {
                    if (t === 'н' || t === 'h') absCount++;
                    else if (/^[1-5]$/.test(t) && !cell.closest('sub')) marksCount++;
                });
            }
        });

        if (!nameEl) return;
        if (extSettings.highlightStudent) { nameEl.style.borderLeft = "4px solid #9b59b6"; nameEl.style.paddingLeft = "5px"; }
        if (extSettings.calcAttendance) {
            nameEl.classList.add('mesh-tooltip-target');
            nameEl.dataset.abs = absCount; nameEl.dataset.total = absCount + marksCount;
            nameEl.dataset.pct = (absCount + marksCount) > 0 ? Math.round((absCount / (absCount + marksCount)) * 100) : 0;
        }
        if (extSettings.focusMode && fAvg >= 4.80) row.classList.add('mesh-dimmed-row'); else row.classList.remove('mesh-dimmed-row');
    });
}

// ==========================================
// 2. MAIN GRADING WORKFLOW
// ==========================================

function startGradingFlow() {
    // Step 1: Force column picker
    if (selectedColumns.length === 0) {
        startColumnPicker();
    } else {
        // Step 2: Student Selector
        showStudentSelector();
    }
}

// ==========================================
// 3. STUDENT SELECTOR (NEW STEP)
// ==========================================

function showStudentSelector() {
    // Removes old panels
    ['mesh-student-selector', 'mesh-student-overlay', 'mesh-buffer-panel', 'mesh-buffer-overlay'].forEach(id => {
        const el = document.getElementById(id); if (el) el.remove();
    });

    // Lock body scroll
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const restoreScroll = () => { document.body.style.overflow = originalOverflow; };

    const students = [];
    const rows = document.querySelectorAll(SELECTORS.tableRows);

    rows.forEach(row => {
        if (row.getBoundingClientRect().height === 0) return;

        let studentName = null;
        let fAvg = 0;

        // Enhanced Filtering: Exclude MDK, Themes, etc.
        const rowText = row.innerText || "";
        if (rowText.includes('МДК') || rowText.includes('Тема') || rowText.includes('ИБС') || rowText.includes('Subject')) return;

        row.querySelectorAll('span, div, p, td').forEach(cell => {
            if (cell.children.length > 0 && cell.tagName !== 'TD') return;
            const text = cell.innerText ? cell.innerText.trim() : "";
            if (!studentName && text.split(' ').length >= 2 && /^[А-ЯЁ]/.test(text) && !text.includes('Ср')) {
                studentName = text;
            }
            if (/^[2-5][.,]\d{2}$/.test(text)) {
                fAvg = parseFloat(text.replace(',', '.'));
            }
        });

        if (studentName) {
            // Clean key
            let cleanNameKey = studentName.toLowerCase().replace(/[^а-яё]/g, '');
            students.push({
                name: studentName,
                key: cleanNameKey,
                avg: fAvg,
                checked: true // Default checked
            });
        }
    });

    if (students.length === 0) {
        alert("Студенты не найдены!");
        restoreScroll();
        return;
    }

    // Build UI
    const overlay = document.createElement('div');
    overlay.className = 'mesh-modal-overlay';
    overlay.id = 'mesh-student-overlay';
    document.body.appendChild(overlay);

    const panel = document.createElement('div');
    panel.className = 'mesh-modal-panel';
    panel.id = 'mesh-student-selector';
    panel.style.width = '450px';
    panel.style.maxHeight = '80vh';

    const header = document.createElement('div');
    header.className = 'mesh-modal-header';
    header.innerHTML = `
        <div style="font-size:18px;font-weight:bold;">👤 Выбор студентов</div>
        <div style="position:absolute; right:15px; top:15px; cursor:pointer; font-size:20px;" id="mesh-ss-close">❌</div>
        <div style="font-size:12px;color:rgba(255,255,255,0.7);margin-top:4px;">Всего: ${students.length}</div>
        <div style="margin-top:10px; display:flex; gap:10px; font-size:12px;">
             <button id="mesh-sel-all" style="background:#2ecc71;border:none;border-radius:4px;padding:2px 8px;color:white;cursor:pointer;">Все</button>
             <button id="mesh-sel-none" style="background:#e74c3c;border:none;border-radius:4px;padding:2px 8px;color:white;cursor:pointer;">Никого</button>
             <button id="mesh-sel-bad" style="background:#f39c12;border:none;border-radius:4px;padding:2px 8px;color:white;cursor:pointer;">Балл < 3.5</button>
             <button id="mesh-sel-good" style="background:#3498db;border:none;border-radius:4px;padding:2px 8px;color:white;cursor:pointer;">Балл > 3.5</button>
        </div>
    `;
    panel.appendChild(header);

    // Close logic
    setTimeout(() => {
        const closeBtn = document.getElementById('mesh-ss-close');
        if (closeBtn) closeBtn.onclick = () => { overlay.remove(); panel.remove(); window.location.reload(); };
    }, 100);

    const list = document.createElement('div');
    list.className = 'mesh-modal-content';

    const renderList = () => {
        list.innerHTML = '';
        students.forEach((s, idx) => {
            const row = document.createElement('div');
            row.className = 'mesh-list-row';

            const chk = document.createElement('input');
            chk.type = 'checkbox';
            chk.checked = s.checked;
            chk.style.cursor = 'pointer';
            chk.onchange = (e) => { s.checked = e.target.checked; updateCount(); };

            const name = document.createElement('span');
            name.style.cssText = 'flex:1;font-size:13px;';
            name.textContent = s.name;

            const avg = document.createElement('span');
            avg.style.cssText = `font-weight:bold;font-size:13px;color:${s.avg >= 4.5 ? '#2ecc71' : s.avg >= 3.5 ? '#3498db' : s.avg >= 2.5 ? '#f39c12' : '#e74c3c'};`;
            avg.textContent = s.avg.toFixed(2);

            row.append(chk, name, avg);
            list.appendChild(row);
        });
    };
    renderList();
    panel.appendChild(list);

    const footer = document.createElement('div');
    footer.className = 'mesh-modal-footer';

    const nextBtn = document.createElement('button');
    nextBtn.textContent = 'Далее (Буфер) ➡';
    nextBtn.style.cssText = 'flex:1;padding:10px;border:none;border-radius:10px;cursor:pointer;background:linear-gradient(135deg,#27ae60,#2ecc71);color:white;font-weight:bold;font-size:14px;';

    const updateCount = () => {
        const c = students.filter(s => s.checked).length;
        nextBtn.textContent = c > 0 ? `Далее (Выбрано: ${c}) ➡` : 'Выберите студентов!';
        nextBtn.disabled = c === 0;
        nextBtn.style.opacity = c === 0 ? 0.5 : 1;
    };
    updateCount();

    nextBtn.onclick = () => {
        selectedStudents.clear();
        students.filter(s => s.checked).forEach(s => selectedStudents.add(s.key));
        overlay.remove();
        panel.remove();
        restoreScroll();
        scanAndShowBuffer();
    };

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Отмена';
    cancelBtn.style.cssText = 'padding:10px 15px;border:1px solid rgba(255,255,255,0.2);border-radius:10px;cursor:pointer;background:transparent;color:#aaa;font-size:14px;';
    cancelBtn.onclick = () => {
        overlay.remove(); panel.remove(); selectedColumns = [];
        restoreScroll();
    }; // Reset flow

    footer.append(nextBtn, cancelBtn);
    panel.appendChild(footer);

    document.body.appendChild(panel);

    // Filter Logic
    document.getElementById('mesh-sel-all').onclick = () => { students.forEach(s => s.checked = true); renderList(); updateCount(); };
    document.getElementById('mesh-sel-none').onclick = () => { students.forEach(s => s.checked = false); renderList(); updateCount(); };
    document.getElementById('mesh-sel-bad').onclick = () => { students.forEach(s => s.checked = (s.avg < 3.5)); renderList(); updateCount(); };
    document.getElementById('mesh-sel-good').onclick = () => { students.forEach(s => s.checked = (s.avg >= 3.5)); renderList(); updateCount(); };
}

// ==========================================
// 4. BUFFER PANEL (STEP 3)
// ==========================================

function findDefaultControlFormId() {
    // Look for FastSelect items (likely in the top bar or headers)
    const items = document.querySelectorAll('[data-test-component*="FastSelectControlForm"]');
    for (const item of items) {
        if (item.innerText.includes('Практическая') || item.innerText.includes('Практическое')) {
            const attr = item.getAttribute('data-test-component');
            const match = attr.match(/FastSelectControlForm-(\d+)-/);
            if (match) return parseInt(match[1], 10);
        }
    }
    return null;
}

function scanAndShowBuffer() {
    gradeBuffer = [];
    const rows = document.querySelectorAll(SELECTORS.tableRows);

    // Update column coordinates to handle scrolling/resize
    const currentColumns = selectedColumns.map(col => {
        if (col.element && col.element.isConnected) {
            const rect = col.element.getBoundingClientRect();
            return { x: rect.left + rect.width / 2, width: rect.width, element: col.element };
        }
        return col; // Fallback to stored coords
    });

    rows.forEach(row => {
        if (row.getBoundingClientRect().height === 0) return;

        let studentName = null;
        let fAvg = 0;

        row.querySelectorAll('span, div, p, td').forEach(cell => {
            if (cell.children.length > 0 && cell.tagName !== 'TD') return;
            const text = cell.innerText ? cell.innerText.trim() : "";
            if (!studentName && text.split(' ').length >= 2 && /^[А-ЯЁ]/.test(text) && !text.includes('Ср')) {
                studentName = text;
            }
            if (/^[2-5][.,]\d{2}$/.test(text)) {
                fAvg = parseFloat(text.replace(',', '.'));
            }
        });

        if (!studentName) return;
        let cleanNameKey = studentName.toLowerCase().replace(/[^а-яё]/g, '');

        // Only process selected students
        if (!selectedStudents.has(cleanNameKey)) return;

        // Find empty cells in selected columns (Support Multiple Columns)
        let targetCells = [];
        let gridCells = Array.from(row.querySelectorAll('[role="gridcell"], td, .Dnevnik-grid-cell'));

        gridCells.forEach(c => {
            const r = c.getBoundingClientRect();
            if (r.width === 0) return;
            const cx = r.left + r.width / 2;

            // Check if cell matches ANY selected column
            // Tightened tolerance from 0.45 to 0.4 to avoid "wrong field" errors
            const isInSelectedColumn = currentColumns.some(col => Math.abs(cx - col.x) < col.width * 0.4);

            const hasPhantom = c.querySelector('.mesh-phantom');
            const isEffectiveEmpty = (c.innerText.trim() === '') || hasPhantom;

            if (isInSelectedColumn && isCellEditable(c) && isEffectiveEmpty) {
                targetCells.push(c);
            }
        });

        targetCells.forEach(cell => {
            // Extract IDs IMMEDIATELY
            let attrNode = cell.hasAttribute('data-test-component') ? cell : cell.querySelector('[data-test-component*="markCell-"]');
            if (attrNode) {
                let attr = attrNode.getAttribute('data-test-component');
                const parts = attr.replace('markCell-', '').split('_');

                // Safe parsing of controlFormId
                let cFormId = (parts[2] && parts[2] !== "null" && parts[2] !== "undefined") ? parseInt(parts[2], 10) : null;

                // REMOVED: Auto-fill default logic (caused 400 error)
                // if (!cFormId) { const def = findDefaultControlFormId(); if (def) cFormId = def; }

                let suggested = Math.round(fAvg);
                if (suggested < 2) suggested = 2; if (suggested > 5) suggested = 5;

                gradeBuffer.push({
                    studentName: studentName,
                    cleanNameKey: cleanNameKey,
                    grade: suggested,
                    cell: cell,
                    applied: false,
                    skipped: false,
                    fAvg: fAvg,
                    cellIds: {
                        physId: parts[0],
                        lessonId: parts[1],
                        controlFormId: cFormId
                    }
                });
            }
        });
    });

    if (gradeBuffer.length === 0) {
        alert("Нет пустых ячеек для выбранных студентов в этих столбцах!");
        // Reopen student selector
        showStudentSelector();
        return;
    }

    renderBufferPanel();
}

let isBufferPreviewMode = false;

function renderBufferPanel() {
    ['mesh-buffer-panel', 'mesh-buffer-overlay'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });

    const overlay = document.createElement('div');
    overlay.className = 'mesh-modal-overlay';
    overlay.id = 'mesh-buffer-overlay';
    document.body.appendChild(overlay);

    const panel = document.createElement('div');
    panel.className = 'mesh-modal-panel';
    panel.id = 'mesh-buffer-panel';
    panel.style.width = '500px';
    panel.style.maxHeight = '85vh';

    const header = document.createElement('div');
    header.className = 'mesh-modal-header';
    header.innerHTML = `
        <div style="font-size:18px;font-weight:bold;">📋 Буфер оценок API</div>
        <div style="position:absolute; right:15px; top:15px; display:flex; gap:10px;">
             <span id="mesh-buf-hide" style="cursor:pointer; font-size:20px;">👁️</span>
             <span id="mesh-buf-close" style="cursor:pointer; font-size:20px;">❌</span>
        </div>
        <div style="font-size:12px;color:rgba(255,255,255,0.7);margin-top:4px;">Готово к отправке: <span id="mesh-buf-count">${gradeBuffer.length}</span></div>
        <div style="margin-top:10px; display:flex; gap:10px; align-items:center;">
             <span style="font-size:12px;">Поставить всем:</span>
             <button class="mesh-mass-grade" data-g="5" style="border:none;background:#27ae60;color:white;border-radius:4px;cursor:pointer;padding:2px 8px;">5</button>
             <button class="mesh-mass-grade" data-g="4" style="border:none;background:#2980b9;color:white;border-radius:4px;cursor:pointer;padding:2px 8px;">4</button>
             <button class="mesh-mass-grade" data-g="3" style="border:none;background:#f39c12;color:white;border-radius:4px;cursor:pointer;padding:2px 8px;">3</button>
             <button class="mesh-mass-avg" style="border:none;background:#8e44ad;color:white;border-radius:4px;cursor:pointer;padding:2px 8px;font-size:11px;">Сброс (Средний)</button>
        </div>
    `;
    panel.appendChild(header);

    // Close & Hide Logic
    setTimeout(() => {
        const closeBtn = document.getElementById('mesh-buf-close');
        if (closeBtn) closeBtn.onclick = () => { overlay.remove(); panel.remove(); window.location.reload(); };

        const hideBtn = document.getElementById('mesh-buf-hide');
        if (hideBtn) hideBtn.onclick = () => {
            if (panel.style.opacity === '0.1') {
                panel.style.opacity = '1';
                panel.style.pointerEvents = 'auto';
                const ov = document.getElementById('mesh-buffer-overlay');
                if (ov) ov.style.display = 'block';
            } else {
                panel.style.opacity = '0.1';
                panel.style.pointerEvents = 'none';
                const ov = document.getElementById('mesh-buffer-overlay');
                if (ov) ov.style.display = 'none';

                // Add a small restore button outside
                const restore = document.createElement('div');
                restore.innerText = '👁️';
                restore.style.cssText = 'position:fixed; top:10px; right:10px; font-size:30px; cursor:pointer; z-index:9999999;';
                restore.onclick = () => {
                    panel.style.opacity = '1';
                    panel.style.pointerEvents = 'auto';
                    if (ov) ov.style.display = 'block';
                    restore.remove();
                };
                document.body.appendChild(restore);
            }
        };
    }, 100);

    const list = document.createElement('div');
    list.className = 'mesh-modal-content';

    const renderList = () => {
        list.innerHTML = '';
        gradeBuffer.forEach((item, idx) => {
            const row = document.createElement('div');
            row.className = 'mesh-list-row';
            row.id = `mesh-buf-row-${idx}`;
            if (item.skipped) row.style.opacity = '0.5';

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = !item.skipped;
            checkbox.style.cursor = 'pointer';
            checkbox.onchange = (e) => {
                item.skipped = !e.target.checked;
                row.style.opacity = item.skipped ? '0.5' : '1';
                updateApplyBtn();
            };

            const name = document.createElement('span');
            name.style.cssText = 'flex:1;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
            name.textContent = `${item.studentName} (${item.fAvg})`;

            const input = document.createElement('input');
            input.type = 'number';
            input.className = 'mesh-buf-input';
            input.min = 0; input.max = 5; // Allow 0
            input.value = item.grade;
            input.placeholder = "-";
            input.onchange = (e) => {
                let v = parseInt(e.target.value);
                if (isNaN(v) || v <= 0) {
                    item.skipped = true;
                    item.grade = 0;
                    e.target.value = 0;
                    checkbox.checked = false;
                    row.style.opacity = '0.5';
                    // Remove phantom if exists
                    const phantom = item.cell.querySelector('.mesh-phantom');
                    if (phantom) phantom.remove();
                    item.cell.classList.remove('mesh-phantom-cell');
                } else {
                    if (v > 5) v = 5;
                    item.skipped = false;
                    item.grade = v;
                    e.target.value = v;
                    checkbox.checked = true;
                    row.style.opacity = '1';
                    // Update phantom
                    if (isBufferPreviewMode) {
                        let phantom = item.cell.querySelector('.mesh-phantom');
                        if (!phantom) {
                            phantom = document.createElement('span');
                            phantom.className = 'mesh-phantom';
                            // CRITICALLY IMPORTANT: Append, do not overwrite innerHTML
                            // because we need to keep data-test-component attributes!
                            item.cell.appendChild(phantom);
                            item.cell.classList.add('mesh-phantom-cell');
                        }
                        phantom.innerText = v;
                    }
                }
                updateApplyBtn();
            };

            const status = document.createElement('span');
            status.id = `mesh-buf-status-${idx}`;
            status.style.width = '20px';
            status.textContent = item.applied ? '✅' : (item.error ? '❌' : '');

            row.append(checkbox, name, input, status);
            list.appendChild(row);
        });
    };
    renderList();
    panel.appendChild(list);
    document.body.appendChild(panel); // Fix: Append before footer logic

    const footer = document.createElement('div');
    footer.className = 'mesh-modal-footer';

    const applyBtn = document.createElement('button');
    applyBtn.id = 'mesh-buffer-apply';
    applyBtn.style.cssText = 'flex:1;padding:10px;border:none;border-radius:10px;cursor:pointer;font-weight:bold;font-size:14px;';

    // Initial State: Preview Mode
    // Initial State: Preview Mode
    if (!isBufferPreviewMode) {
        applyBtn.textContent = '👁️ Предпросмотр (Фантомы)';
        applyBtn.style.background = '#3498db';
        applyBtn.style.color = '#fff';
        applyBtn.onclick = () => {
            isBufferPreviewMode = true;
            gradeBuffer.forEach(item => {
                if (!item.skipped && !item.cell.querySelector('.mesh-phantom')) {
                    item.cell.innerHTML = `<span class="mesh-phantom">${item.grade}</span>`;
                    item.cell.classList.add('mesh-phantom-cell');
                }
            });
            renderBufferPanel(); // Re-render to update button state
        };
    } else {
        applyBtn.textContent = '🚀 Подтвердить и Запустить API';
        applyBtn.style.background = 'linear-gradient(135deg,#27ae60,#2ecc71)';
        applyBtn.style.color = '#fff';
        applyBtn.onclick = () => submitBufferViaAPI();
    }

    const updateApplyBtn = () => {
        const c = gradeBuffer.filter(b => !b.skipped).length;
        if (isBufferPreviewMode) {
            applyBtn.textContent = `🚀 Подтвердить и Запустить API (${c})`;
        }
        const el = document.getElementById('mesh-buf-count');
        if (el) el.innerText = c;
    };
    if (isBufferPreviewMode) updateApplyBtn();

    const closeBtn = document.createElement('button');
    closeBtn.textContent = 'Назад (Студенты)';
    closeBtn.style.cssText = 'padding:10px;border:1px solid rgba(255,255,255,0.2);border-radius:10px;cursor:pointer;background:transparent;color:#aaa;font-size:14px;';
    closeBtn.onclick = () => {
        overlay.remove(); panel.remove();
        document.body.style.overflow = ''; // Restore scroll roughly
        // Clear Phantoms & Reset Mode
        gradeBuffer.forEach(item => {
            if (item.cell.querySelector('.mesh-phantom')) item.cell.innerHTML = '';
            item.cell.classList.remove('mesh-phantom-cell');
        });
        isBufferPreviewMode = false;
        showStudentSelector();
    };

    footer.append(applyBtn, closeBtn);
    panel.appendChild(footer);

    // document.body.appendChild(panel); // Moved up

    // Mass Actions
    panel.querySelectorAll('.mesh-mass-grade').forEach(btn => {
        btn.onclick = () => {
            const g = parseInt(btn.dataset.g);
            gradeBuffer.forEach(item => {
                if (!item.skipped) {
                    item.grade = g;
                    if (isBufferPreviewMode) {
                        const phantom = item.cell.querySelector('.mesh-phantom');
                        if (phantom) phantom.innerText = g;
                    }
                }
            });
            renderList(); // Re-render inputs
        };
    });
    panel.querySelector('.mesh-mass-avg').onclick = () => {
        gradeBuffer.forEach(item => {
            let suggested = Math.round(item.fAvg); if (suggested < 2) suggested = 2; if (suggested > 5) suggested = 5;
            if (!item.skipped) {
                item.grade = suggested;
                if (isBufferPreviewMode) {
                    const phantom = item.cell.querySelector('.mesh-phantom');
                    if (phantom) phantom.innerText = suggested;
                }
            }
        });
        renderList();
    };
}

// ... (startColumnPicker, findDateColumnHeaders, submitBufferViaAPI remain largely same but moved to bottom) ...

// ==========================================
// 5. API EXECUTION (STEP 4)
// ==========================================

async function submitBufferViaAPI() {
    const toProcess = gradeBuffer.filter(b => !b.skipped && !b.applied);
    if (toProcess.length === 0) { alert("Нечего отправлять!"); return; }

    let localDb = { grade_system_ids: [], control_forms: [] };
    try {
        const stored = window.sessionStorage.getItem('MESH_GLOBAL_DB');
        if (stored) localDb = JSON.parse(stored);
    } catch (e) { }

    if (!confirm(`🚀 Запуск ГЛОБАЛЬНОЙ МАТРИЦЫ (v3)!\n\nСкрипт будет жестко пытаться выставить оценки с Весом = 2.\nПамять очищена.\n\nВыставить ${toProcess.length} оценок?`)) return;

    isRobotActive = true;
    apiErrorLogs = []; // Clear logs
    const applyBtn = document.getElementById('mesh-buffer-apply');
    if (applyBtn) { applyBtn.textContent = '⏳ Глобальная отправка...'; applyBtn.disabled = true; applyBtn.style.background = '#f39c12'; }

    // Auth
    const tk = document.cookie.match(/(?:^|; )aupd_token=([^;]*)/);
    const pr = document.cookie.match(/(?:^|; )profile_id=([^;]*)/);
    const aupd_token = tk ? decodeURIComponent(tk[1]) : null;
    const profile_id = pr ? decodeURIComponent(pr[1]) : null;

    if (!aupd_token || !profile_id) {
        alert("❌ Ошибка авторизации. Обновите страницу (F5).");
        isRobotActive = false;
        if (applyBtn) { applyBtn.disabled = false; applyBtn.style.background = '#e74c3c'; applyBtn.textContent = 'Ошибка Auth'; }
        return;
    }

    let ok = 0; let err = 0;

    // MATRIX MEMORY (Re-enabled per working script)
    let winningGsId = null;
    let winningCfId = undefined;
    let winningWeight = null;
    let firstFatalErrorLog = null;

    for (let i = 0; i < gradeBuffer.length; i++) {
        const item = gradeBuffer[i];
        if (item.skipped || item.applied) continue;

        const statusEl = document.getElementById(`mesh-buf-status-${i}`);
        if (statusEl) statusEl.textContent = '🔄';

        try {
            if (!item.cellIds) throw new Error("Missing cell IDs");
            const { physId, lessonId, controlFormId } = item.cellIds;

            let trueProfileId = localDatabase.ids[physId] || localDatabase.names[item.cleanNameKey] || physId;
            if (!trueProfileId) throw new Error("No Profile ID");

            const domCfId = (controlFormId && !isNaN(controlFormId)) ? parseInt(controlFormId, 10) : null;

            // BUILD MATRIX (Phase Logic from working script)
            let combosToTry = [];

            if (winningGsId !== null) {
                // Use the WINNER
                combosToTry.push({ gs: winningGsId, w: winningWeight, c: winningCfId });
            } else {
                // Brute Force Matrix
                // 1. Grade Systems (Stolen + Defaults + Spy)
                let gsIds = [...new Set([...localDb.grade_system_ids, 50365, 71243, 58343])];

                // 2. Control Forms
                let cfs = [];
                if (domCfId) cfs.push(domCfId); // From DOM
                const defForm = findDefaultControlFormId(); // From Page Header
                if (defForm && !cfs.includes(defForm)) cfs.push(defForm);
                if (localDb.control_forms) localDb.control_forms.forEach(cf => { if (!cfs.includes(cf)) cfs.push(cf); });
                cfs.push(null); // Null always last

                // PHASE A: ABSOLUTE PRIORITY WEIGHT 2
                for (let gs of gsIds) {
                    for (let cf of cfs) {
                        combosToTry.push({ w: 2, gs: gs, c: cf });
                    }
                }

                // PHASE B: If Weight 2 banned, try Weight 1
                for (let gs of gsIds) {
                    for (let cf of cfs) {
                        combosToTry.push({ w: 1, gs: gs, c: cf });
                    }
                }
                // Also add Weight 3 just in case? The working script only does 2 then 1. Let's stick to 2 and 1 for now to match it.
            }

            let success = false;
            let lastErr = "";
            let lastAttemptedPayload = null;

            for (let combo of combosToTry) {
                const payload = {
                    "comment": "", "is_exam": false, "is_criterion": false, "is_point": false, "point_date": "",
                    "schedule_lesson_id": parseInt(lessonId, 10),
                    "student_profile_id": parseInt(trueProfileId, 10),
                    "teacher_id": parseInt(profile_id, 10),
                    "control_form_id": combo.c,
                    "weight": combo.w,
                    "theme_frame_integration_id": null, "course_lesson_topic_id": null,
                    "grade_origins": [{ "grade_origin": String(item.grade), "grade_system_id": combo.gs }],
                    "grade_system_type": false
                };
                lastAttemptedPayload = payload;

                try {
                    const res = await fetch("https://school.mos.ru/api/profeducation/core/teacher/v1/marks", {
                        method: "POST",
                        headers: {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": `Bearer ${aupd_token}`,
                            "Profile-Id": profile_id,
                            "x-mes-subsystem": "journalw"
                        },
                        body: JSON.stringify(payload)
                    });

                    if (res.ok) {
                        success = true;
                        // SAVE WINNER
                        winningGsId = combo.gs;
                        winningWeight = combo.w;
                        winningCfId = combo.c;
                        break;
                    } else {
                        const txt = await res.text();
                        lastErr = `${res.status}: ${txt.substring(0, 40)}`;
                        if (res.status === 401 || res.status === 500) break; // Stop brute force on critical errors
                    }
                } catch (e) { lastErr = e.message; break; }
            }

            if (success) {
                item.applied = true; ok++;
                if (statusEl) statusEl.textContent = '✅';
                item.cell.innerText = item.grade;
                item.cell.style.background = '#27ae60'; item.cell.style.color = 'white';
                const ph = item.cell.querySelector('.mesh-phantom');
                if (ph) ph.remove();
            } else {
                throw new Error(lastErr || "Matrix failed");
            }

        } catch (e) {
            item.error = e.message; err++;
            if (statusEl) statusEl.textContent = '❌';

            const debugInfo = {
                student: item.studentName,
                grade: item.grade,
                error: e.message,
                cellHTML: item.cell ? item.cell.outerHTML.substring(0, 200) : "N/A"
            };
            apiErrorLogs.push(debugInfo);
            if (err === 1) firstFatalErrorLog = { server_response: e.message, last_payload_tried: item.error }; // Simply capture error
        }
        await sleep(150);
    }

    isRobotActive = false;
    if (applyBtn) {
        applyBtn.textContent = `Готово: ${ok} | Ошибок: ${err}`;
        applyBtn.style.background = err > 0 ? '#e74c3c' : '#27ae60';
        applyBtn.disabled = false;

        if (err > 0) {
            const footer = applyBtn.parentElement;
            const oldLog = document.getElementById('mesh-log-btn');
            if (oldLog) oldLog.remove();

            const logBtn = document.createElement('button');
            logBtn.id = 'mesh-log-btn';
            logBtn.textContent = `📄 Логи (${err})`;
            logBtn.style.cssText = 'padding:10px;border:none;border-radius:10px;cursor:pointer;background:#7f8c8d;color:white;font-weight:bold;margin-left:10px;';
            logBtn.onclick = () => {
                prompt("Скопируйте лог ошибок (Ctrl+C):", JSON.stringify(apiErrorLogs, null, 2));
            };
            footer.appendChild(logBtn);
        }

        setTimeout(() => { if (ok > 0) window.location.reload(); }, 2500);
    }
}

// ==========================================
// 6. COLUMN PICKER (STEP 1)
// ==========================================

function startColumnPicker() {
    const oldPicker = document.getElementById('mesh-col-picker-bar');
    if (oldPicker) oldPicker.remove();

    const headerCells = findDateColumnHeaders();
    if (headerCells.length === 0) { console.log('SpeedMesh: Столбцы не найдены (Silent Fail)'); return; }

    const pickerSelections = new Set();
    if (selectedColumns.length > 0) {
        headerCells.forEach((hc, idx) => {
            if (selectedColumns.some(col => Math.abs(hc.x - col.x) < hc.width * 0.6)) pickerSelections.add(idx);
        });
    }

    const bar = document.createElement('div');
    bar.id = 'mesh-col-picker-bar';
    bar.style.cssText = 'position:fixed; top:0; left:0; right:0; z-index:9999999; background:linear-gradient(135deg,#2c3e50,#34495e); color:#fff; padding:12px 20px; display:flex; align-items:center; gap:12px; font-family:"Segoe UI"; border-bottom:2px solid #f1c40f;';
    bar.innerHTML = `
        <span style="font-size:20px;">🎯</span><span style="flex:1;">Выберите столбцы (Шаг 1 из 3)</span>
        <button id="mesh-cp-done" style="padding:8px 20px; border:none; border-radius:8px; background:linear-gradient(135deg,#27ae60,#2ecc71); color:#fff; font-weight:bold; cursor:pointer;">Далее ➡</button>
        <button id="mesh-cp-cancel" style="padding:8px 16px; border:1px solid rgba(255,255,255,0.3); border-radius:8px; background:transparent; color:#fff; cursor:pointer;">Отмена</button>
    `;
    document.body.appendChild(bar);

    // Cancel Button Logic
    const cancelBtn = document.getElementById('mesh-cp-cancel');
    if (cancelBtn) {
        cancelBtn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            window.location.reload();
        };
    }

    const overlays = [];
    headerCells.forEach((hc, idx) => {
        const rect = hc.el.getBoundingClientRect();
        const ov = document.createElement('div');
        const isSel = pickerSelections.has(idx);
        ov.style.cssText = `position:fixed; top:${rect.top}px; left:${rect.left}px; width:${rect.width}px; height:${document.documentElement.clientHeight - rect.top}px; background:${isSel ? 'rgba(46,204,113,0.2)' : 'rgba(241,196,15,0.08)'}; border:2px dashed ${isSel ? '#2ecc71' : 'rgba(241,196,15,0.4)'}; z-index:9999990; cursor:pointer;`;

        ov.onclick = (e) => {
            e.stopPropagation();
            if (pickerSelections.has(idx)) {
                pickerSelections.delete(idx);
                ov.style.background = 'rgba(241,196,15,0.08)'; ov.style.borderColor = 'rgba(241,196,15,0.4)';
            } else {
                pickerSelections.add(idx);
                ov.style.background = 'rgba(46,204,113,0.2)'; ov.style.borderColor = '#2ecc71';
            }
        };
        document.body.appendChild(ov);
        overlays.push(ov);
    });

    const cleanup = () => { overlays.forEach(o => o.remove()); bar.remove(); };

    document.getElementById('mesh-cp-cancel').onclick = () => {
        cleanup();
        isPaused = true;
        selectedColumns = [];
        // Optional: Inject a small "Restart" button if needed, but for now just pause.
        console.log("SpeedMesh Paused. Reload to reset or waiting for user trigger.");
    };

    document.getElementById('mesh-cp-done').onclick = () => {
        if (pickerSelections.size === 0) { alert('Выберите столбец!'); return; }
        selectedColumns = [];
        pickerSelections.forEach(idx => {
            const hc = headerCells[idx];
            const rect = hc.el.getBoundingClientRect();
            // Store element reference
            selectedColumns.push({ x: rect.left + rect.width / 2, width: rect.width, element: hc.el });
        });
        cleanup();
        showStudentSelector(); // Go to STEP 2
    };
}

function findDateColumnHeaders() {
    const results = [];
    const schedCells = document.querySelectorAll('[data-test-component*="scheduleLessonCell"]');
    if (schedCells.length > 0) {
        const seenX = new Set();
        schedCells.forEach(el => {
            const wrapper = el.parentElement || el;
            const rect = wrapper.getBoundingClientRect();
            if (rect.width === 0) return;
            const xKey = Math.round(rect.left);
            if (seenX.has(xKey)) return;
            seenX.add(xKey);
            results.push({ el: wrapper, x: rect.left + rect.width / 2, width: rect.width });
        });
        return results;
    }
    document.querySelectorAll('[role="columnheader"], th').forEach(cell => {
        const rect = cell.getBoundingClientRect();
        if (rect.top > 200 || rect.width === 0) return;
        if (/\d/.test(cell.innerText)) results.push({ el: cell, x: rect.left + rect.width / 2, width: rect.width });
    });
    return results;
}

// ... Restored Tools (Export, Picker, etc.) same as previous version ...

function startExport() {
    const rows = document.querySelectorAll(SELECTORS.tableRows);
    if (rows.length === 0) { alert("Таблица не найдена"); return; }
    let csv = ["Предмет;Оценки;Средний"];
    rows.forEach(row => {
        let subject = "", marks = [], avg = "";
        const raw = row.innerText.split(/[\n\t]+/);
        raw.forEach(t => {
            t = t.trim();
            if (/^[2-5][.,]\d{2}$/.test(t)) avg = t;
            else if (/^[1-5]$/.test(t) || ['н', 'п'].includes(t.toLowerCase())) marks.push(t);
            else if (t.length > 3 && !/\d/.test(t) && !subject) subject = t;
        });
        if (subject || marks.length > 0) csv.push(`"${subject}";"${marks.join(' ')}";${avg}`);
    });
    const blob = new Blob(["\uFEFF" + csv.join("\r\n")], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `MESH_Export_${new Date().toLocaleDateString()}.csv`;
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
}

function startPicking() {
    isPicking = true; selectedSet.clear();
    injectStyle("mesh-picker-style", `.mesh-hover{outline:3px solid #e74c3c!important;cursor:pointer!important;z-index:9999}.mesh-selected{outline:4px solid #c0392b!important;background:rgba(231,76,60,0.3)!important}`);
    const panel = document.createElement('div'); panel.id = 'mesh-picker-panel';
    panel.style.cssText = "position:fixed;bottom:20px;right:20px;background:#fff;padding:15px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.2);z-index:999999;";
    panel.innerHTML = `<div>Выбор: <b id="mesh-pick-count">0</b></div><button id="mesh-pick-ok">Скрыть</button><button id="mesh-pick-cancel">Отмена</button>`;
    document.body.appendChild(panel);

    document.getElementById('mesh-pick-cancel').onclick = () => { isPicking = false; selectedSet.forEach(e => e.classList.remove('mesh-selected')); document.getElementById('mesh-picker-panel').remove(); };
    document.getElementById('mesh-pick-ok').onclick = () => {
        selectedSet.forEach(el => { el.style.display = 'none'; });
        isPicking = false; selectedSet.clear(); document.getElementById('mesh-picker-panel').remove();
    };
    document.addEventListener('mouseover', (e) => {
        if (!isPicking) return;
        if (hoveredEl) hoveredEl.classList.remove('mesh-hover');
        hoveredEl = e.target; hoveredEl.classList.add('mesh-hover');
        e.preventDefault(); e.stopPropagation();
    }, true);
    document.addEventListener('click', (e) => {
        if (!isPicking || e.target.closest('#mesh-picker-panel')) return;
        e.preventDefault(); e.stopPropagation();
        if (selectedSet.has(e.target)) { selectedSet.delete(e.target); e.target.classList.remove('mesh-selected'); }
        else { selectedSet.add(e.target); e.target.classList.add('mesh-selected'); }
        document.getElementById('mesh-pick-count').innerText = selectedSet.size;
    }, true);
}

function handleBatchClick(e) { /* ... */ }
function handleFormInput(e) { /* ... */ }
function restoreForms() { /* ... */ }
function handleTooltipShow(e) {
    if (!extSettings.calcAttendance) return;
    const target = e.target.closest('.mesh-tooltip-target');
    if (!target) return;
    tooltipElement.innerHTML = `<b>Статистика:</b><br>Пропусков: ${target.dataset.abs}<br>Процент: ${target.dataset.pct}%`;
    tooltipElement.style.display = 'block';
    const move = (ev) => { tooltipElement.style.left = (ev.clientX + 15) + 'px'; tooltipElement.style.top = (ev.clientY + 15) + 'px'; };
    move(e); target.addEventListener('mousemove', move);
}
function handleTooltipHide(e) { if (tooltipElement) tooltipElement.style.display = 'none'; }
function initTooltip() {
    if (!document.getElementById('mesh-custom-tooltip')) {
        tooltipElement = document.createElement('div'); tooltipElement.id = 'mesh-custom-tooltip'; document.body.appendChild(tooltipElement);
    }
}
function isCellEditable(el) {
    if (el.className && typeof el.className === 'string' && el.className.match(/(disabled|locked|readonly)/i)) return false;
    const bg = window.getComputedStyle(el).backgroundColor;
    const rgbMatch = bg.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (rgbMatch) {
        const r = parseInt(rgbMatch[1]), g = parseInt(rgbMatch[2]), b = parseInt(rgbMatch[3]);
        if (r >= 230 && r <= 250 && Math.abs(r - g) <= 10 && Math.abs(g - b) <= 10) return false;
        if (r === 242 && g === 242 && b === 242) return false;
    }
    return true;
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));