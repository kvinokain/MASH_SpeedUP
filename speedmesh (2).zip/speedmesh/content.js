console.log("MESH Ultimate v5.2: Loaded (Fix Layout)");

// === КОНСТАНТЫ ===
const SELECTORS = {
    noise: ['.banner-container', '.ad-wrapper', 'div[class*="banner"]', '.news-block-sidebar', 'footer', '[aria-label="Реклама"]'],
    studentName: '.student-fio, .header__profile-name, td[data-col-title="ФИО"] span',
    tableRows: 'tr, div[role="row"], .Dnevnik-grid-row',
    checkbox: 'input[type="checkbox"]'
};

// === СОСТОЯНИЕ ===
let settings = {};
let customRules = [];
let logoutInterval = null;
let isPicking = false;
let selectedSet = new Set();
let hoveredEl = null;
let lastCheckedBox = null;

// === ЗАПУСК ===
init();

function init() {
    chrome.storage.sync.get(null, (data) => {
        settings = data;
        customRules = data.customRules || [];
        applyAllSettings();
        
        // Observer следит за изменениями на странице, чтобы красить новые оценки
        const observer = new MutationObserver(() => {
            periodicChecks();
        });
        observer.observe(document.body, { childList: true, subtree: true });
        
        setInterval(ensureStylesExist, 1000);
    });
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "updateSettings") { settings = req.settings; applyAllSettings(); }
    if (req.action === "refreshRules") { customRules = req.rules; applyAllSettings(); }
    if (req.action === "startPicking") startPicking();
    if (req.action === "openExportMenu") showExportModal();
});

// === ПРИМЕНЕНИЕ НАСТРОЕК ===
function applyAllSettings() {
    if (logoutInterval) clearInterval(logoutInterval);
    if (settings.antiLogout) {
        logoutInterval = setInterval(() => fetch(window.location.href, {method:'HEAD'}).catch(()=>{}), 270000);
    }

    generateAndInjectCSS();

    document.removeEventListener('click', handleBatchClick);
    document.removeEventListener('input', handleFormInput);
    
    if (settings.batchClick) document.addEventListener('click', handleBatchClick);
    if (settings.formSaver) {
        document.addEventListener('input', handleFormInput);
        restoreForms(); 
    }
    
    processContent();
}

function generateAndInjectCSS() {
    let css = "";
    if (settings.disableAnimations) css += `*, *::before, *::after { transition: none !important; animation: none !important; scroll-behavior: auto !important; }`;
    if (settings.hideAds) SELECTORS.noise.forEach(sel => css += `${sel} { display: none !important; }`);
    
    if (customRules && customRules.length > 0) {
        customRules.forEach(rule => {
            if (rule.action === 'hide') css += `${rule.selector} { display: none !important; }\n`;
            else if (rule.action === 'color') css += `${rule.selector} { background-color: ${rule.value} !important; background-image: none !important; }\n`;
        });
    }

    css += `.mesh-duplicate-warning { border: 2px solid #e67e22 !important; background-color: #fdf2e9 !important; position: relative; }`;
    css += `.mesh-duplicate-icon { position: absolute; right: 5px; top: 50%; transform: translateY(-50%); color: #e67e22; font-weight: bold; cursor: help; }`;

    injectStyle("mesh-main-style", css);
}

function ensureStylesExist() {
    const style = document.getElementById("mesh-main-style");
    if (!style && (settings.hideAds || (customRules && customRules.length > 0))) {
        generateAndInjectCSS();
    }
}

function periodicChecks() {
    if (settings.highlightGrades || settings.highlightStudent) processContent();
    if (settings.duplicateFinder) checkDuplicates();
}

// === ОБРАБОТКА КОНТЕНТА (ЗДЕСЬ ИСПРАВЛЕНИЯ) ===
function processContent() {
    const avgGradeRegex = /^[2-5],\d{2}$/; // "4,50"
    
    document.querySelectorAll('span, div, p, td, .Dnevnik-grid-cell').forEach(el => {
        if (!el.firstChild) return; // Пустые пропускаем

        const text = el.innerText ? el.innerText.trim() : "";
        if (!text) return;

        // --- ЛОГИКА ПОДСВЕТКИ ОЦЕНОК (ИСПРАВЛЕНАЯ) ---
        if (settings.highlightGrades && avgGradeRegex.test(text)) {
            // Чтобы не накладывать стили 100 раз подряд
            if (el.dataset.meshProcessed) return;

            const val = parseFloat(text.replace(',', '.'));
            
            // НОВЫЕ СТИЛИ ДЛЯ РОВНОГО ОТОБРАЖЕНИЯ
            el.style.cssText += `
                display: inline-flex !important;
                justify-content: center !important;
                align-items: center !important;
                min-width: 42px !important;    /* Фиксированная ширина, чтобы было ровно */
                height: 24px !important;       /* Фиксированная высота */
                border-radius: 12px !important;/* Округление (Pill shape) */
                font-weight: 600 !important;
                font-size: 13px !important;
                color: #fff !important;
                margin: 0 auto !important;     /* Центрирование внутри ячейки */
                box-shadow: 0 2px 4px rgba(0,0,0,0.15) !important; /* Легкая тень */
                line-height: 1 !important;
            `;
            
            // Если родитель - ячейка таблицы, заставляем её центрировать наш бейдж
            if (el.parentElement && (el.parentElement.tagName === 'TD' || el.parentElement.getAttribute('role') === 'gridcell')) {
                el.parentElement.style.textAlign = 'center';
                el.parentElement.style.verticalAlign = 'middle';
            }

            // Цвета
            if(val >= 4.5) el.style.backgroundColor = '#27ae60'; // Зеленый (5)
            else if(val >= 3.5) el.style.backgroundColor = '#2980b9'; // Синий (4)
            else if(val >= 2.5) el.style.backgroundColor = '#f39c12'; // Оранжевый (3)
            else el.style.backgroundColor = '#c0392b'; // Красный (2)
            
            el.dataset.meshProcessed = "true";
        }

        // Подсветка ученика
        if (settings.highlightStudent && el.matches(SELECTORS.studentName)) {
             if (el.dataset.meshStudent) return;
             el.style.borderLeft = '4px solid #3498db';
             el.style.backgroundColor = '#f0f8ff';
             el.style.paddingLeft = '8px';
             el.style.display = 'block';
             el.dataset.meshStudent = "true";
        }
    });
}

// === ПРОДУКТИВНОСТЬ ===
function handleBatchClick(e) {
    if (e.target.type !== 'checkbox') return;
    if (e.shiftKey && lastCheckedBox && lastCheckedBox !== e.target) {
        const checkboxes = Array.from(document.querySelectorAll(SELECTORS.checkbox));
        const start = checkboxes.indexOf(lastCheckedBox);
        const end = checkboxes.indexOf(e.target);
        if (start > -1 && end > -1) {
            const targetState = lastCheckedBox.checked;
            for (let i = Math.min(start, end); i <= Math.max(start, end); i++) {
                if (checkboxes[i] !== e.target) {
                    checkboxes[i].checked = targetState;
                    checkboxes[i].dispatchEvent(new Event('click', { bubbles: true }));
                }
            }
        }
    }
    lastCheckedBox = e.target;
}

function handleFormInput(e) {
    const el = e.target;
    if ((el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && el.type === 'text')) && !el.type.match(/password|hidden/)) {
        const key = `mesh_save_${window.location.pathname}_${getRobustSelector(el)}`;
        if (el.value.trim() === '') localStorage.removeItem(key);
        else {
            localStorage.setItem(key, el.value);
            el.style.borderColor = '#2ecc71'; 
            setTimeout(() => el.style.borderColor = '', 1000);
        }
    }
}

function restoreForms() {
    document.querySelectorAll('input[type="text"], textarea').forEach(el => {
        const key = `mesh_save_${window.location.pathname}_${getRobustSelector(el)}`;
        const val = localStorage.getItem(key);
        if (val && el.value === '') {
            el.value = val;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.style.backgroundColor = '#e8f8f5';
        }
    });
}

function checkDuplicates() {
    const students = document.querySelectorAll(SELECTORS.studentName);
    const namesMap = new Map();
    students.forEach(el => {
        el.classList.remove('mesh-duplicate-warning');
        const icon = el.querySelector('.mesh-duplicate-icon'); if (icon) icon.remove();
        const surname = el.innerText.trim().split(' ')[0].toLowerCase();
        if (!surname) return;
        if (!namesMap.has(surname)) namesMap.set(surname, []);
        namesMap.get(surname).push(el);
    });
    namesMap.forEach((list) => {
        if (list.length > 1) {
            list.forEach(el => {
                el.classList.add('mesh-duplicate-warning');
                const i = document.createElement('span'); i.className = 'mesh-duplicate-icon'; i.innerText = '👥'; el.appendChild(i);
            });
        }
    });
}

function getRobustSelector(el) {
    if (el.id && !/\d{4,}/.test(el.id)) return '#' + el.id;
    const attributes = ['data-testid', 'data-id', 'name', 'role', 'aria-label'];
    for (let attr of attributes) {
        if (el.hasAttribute(attr)) return `${el.tagName.toLowerCase()}[${attr}="${el.getAttribute(attr)}"]`;
    }
    if (el.className && typeof el.className === 'string') {
        const validClasses = el.className.split(/\s+/).filter(c => !c.startsWith('mesh-') && !c.includes('hover') && !c.includes('active') && !/\d{3,}/.test(c) && !/^css-/.test(c));
        if (validClasses.length > 0 && document.querySelectorAll('.' + validClasses.join('.')).length === 1) return '.' + validClasses.join('.');
    }
    let path = [];
    while (el.parentElement) {
        let tag = el.tagName.toLowerCase();
        let siblings = Array.from(el.parentElement.children).filter(e => e.tagName.toLowerCase() === tag);
        if (siblings.length > 1) { let index = siblings.indexOf(el) + 1; path.unshift(`${tag}:nth-of-type(${index})`); } 
        else { path.unshift(tag); }
        el = el.parentElement;
    }
    return path.join(' > ');
}

// === PICKER (РЕДАКТОР) ===
function startPicking() {
    isPicking = true; selectedSet.clear(); createPickerPanel();
    const css = `.mesh-hover { outline: 3px solid #e74c3c !important; cursor: pointer !important; z-index: 9999; } .mesh-selected { outline: 4px solid #c0392b !important; background: rgba(231,76,60,0.3) !important; }`;
    injectStyle("mesh-picker-style", css);
}
function stopPicking() {
    isPicking = false; selectedSet.forEach(el => el.classList.remove('mesh-selected')); selectedSet.clear();
    ['mesh-picker-style', 'mesh-panel', 'mesh-modal'].forEach(id => { const el = document.getElementById(id); if(el) el.remove(); });
    if (hoveredEl) hoveredEl.classList.remove('mesh-hover');
}
document.addEventListener('mouseover', (e) => {
    if (!isPicking || e.target.closest('#mesh-panel') || e.target.closest('#mesh-modal')) return;
    e.preventDefault(); e.stopPropagation();
    if (hoveredEl && hoveredEl !== e.target) hoveredEl.classList.remove('mesh-hover');
    hoveredEl = e.target;
    if (!selectedSet.has(hoveredEl)) hoveredEl.classList.add('mesh-hover');
}, true);
document.addEventListener('click', (e) => {
    if (!isPicking || e.target.closest('#mesh-panel') || e.target.closest('#mesh-modal')) return;
    e.preventDefault(); e.stopPropagation();
    const t = e.target;
    if (selectedSet.has(t)) { selectedSet.delete(t); t.classList.remove('mesh-selected'); t.classList.add('mesh-hover'); }
    else { selectedSet.add(t); t.classList.remove('mesh-hover'); t.classList.add('mesh-selected'); }
    updatePickerCount();
}, true);

function createPickerPanel() {
    if (document.getElementById('mesh-panel')) return;
    const div = document.createElement('div'); div.id = 'mesh-panel';
    div.innerHTML = `<div style="font-weight:bold;margin-bottom:5px;">Выбор</div><div style="font-size:12px;margin-bottom:10px;">Выбрано: <b id="mesh-count">0</b></div><button id="mesh-btn-ok" style="background:#e74c3c;color:#fff;border:none;padding:5px 10px;border-radius:4px;cursor:pointer;">Настроить</button><button id="mesh-btn-cancel" style="background:#7f8c8d;color:#fff;border:none;padding:5px 10px;border-radius:4px;cursor:pointer;margin-left:5px;">Отмена</button>`;
    div.style.cssText = "position:fixed;bottom:20px;right:20px;background:#fff;padding:15px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.2);z-index:999999;font-family:sans-serif;";
    document.body.appendChild(div);
    document.getElementById('mesh-btn-cancel').onclick = stopPicking;
    document.getElementById('mesh-btn-ok').onclick = showPickerModal;
}
function updatePickerCount() { const el = document.getElementById('mesh-count'); if(el) el.innerText = selectedSet.size; }

function showPickerModal() {
    if (selectedSet.size === 0) return alert("Выберите хотя бы один блок!");
    const div = document.createElement('div'); div.id = 'mesh-modal';
    div.innerHTML = `<div style="font-weight:bold;margin-bottom:10px;">Действие</div><button id="act-hide" style="width:100%;margin-bottom:5px;padding:8px;cursor:pointer;background:#e74c3c;color:white;border:none;border-radius:4px;">Скрыть</button><div style="display:flex;align-items:center;gap:5px;margin-bottom:10px;"><input type="color" id="act-color" value="#e74c3c"><span>Покрасить</span></div><button id="act-save" style="width:100%;background:#27ae60;color:#fff;border:none;padding:8px;cursor:pointer;border-radius:4px;">Сохранить</button><button id="act-close" style="width:100%;margin-top:5px;border:none;background:none;cursor:pointer;color:#666;">Закрыть</button>`;
    div.style.cssText = "position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;padding:20px;width:200px;border-radius:8px;box-shadow:0 0 20px rgba(0,0,0,0.3);z-index:1000000;font-family:sans-serif;";
    document.body.appendChild(div);
    let action=null, val=null;
    document.getElementById('act-hide').onclick=()=>{ action='hide'; selectedSet.forEach(el=>{el.style.display='none';el.style.backgroundColor='';}); };
    document.getElementById('act-color').oninput=(e)=>{ action='color'; val=e.target.value; selectedSet.forEach(el=>{el.style.display='';el.style.backgroundColor=val;el.style.backgroundImage='none';}); };
    document.getElementById('act-close').onclick=()=>{ selectedSet.forEach(el=>{el.style.display='';el.style.backgroundColor='';}); div.remove(); };
    document.getElementById('act-save').onclick=()=>{ 
        if(!action)return alert("Выберите действие!"); 
        const newRules=[]; 
        selectedSet.forEach(el=>{ newRules.push({selector: getRobustSelector(el), action: action, value: val}); }); 
        const c=[...customRules,...newRules]; 
        chrome.storage.sync.set({customRules:c},()=>{ customRules=c; stopPicking(); applyAllSettings(); }); 
    };
}

// === EXPORT ===
function showExportModal() {
    const old = document.getElementById('mesh-export-modal'); if (old) old.remove();
    const div = document.createElement('div'); div.id = 'mesh-export-modal';
    div.innerHTML = `<div style="font-weight:bold;font-size:16px;margin-bottom:15px;padding-bottom:10px;border-bottom:1px solid #eee;">📊 Экспорт в Excel</div><div style="margin-bottom:15px;font-size:14px;"><label style="display:block;margin-bottom:5px;"><input type="checkbox" id="exp-subj" checked> Предмет</label><label style="display:block;margin-bottom:5px;"><input type="checkbox" id="exp-marks" checked> Оценки</label><label style="display:block;margin-bottom:5px;"><input type="checkbox" id="exp-avg" checked> Средний балл</label></div><div style="display:flex;gap:10px;"><button id="exp-btn-dl" style="flex:1;background:#27ae60;color:#fff;border:none;padding:10px;border-radius:5px;cursor:pointer;font-weight:bold;">Скачать CSV</button><button id="exp-btn-cls" style="background:#f8f9fa;border:1px solid #ddd;padding:10px;border-radius:5px;cursor:pointer;">Закрыть</button></div><div id="exp-status" style="margin-top:10px;font-size:12px;color:#7f8c8d;"></div>`;
    div.style.cssText = `position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:280px;background:white;padding:20px;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,0.3);z-index:9999999;font-family:sans-serif;color:#333;`;
    const overlay = document.createElement('div'); overlay.id = 'mesh-export-overlay'; overlay.style.cssText = `position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.4);z-index:9999998;backdrop-filter:blur(2px);`;
    document.body.appendChild(overlay); document.body.appendChild(div);
    const close = () => { div.remove(); overlay.remove(); };
    document.getElementById('exp-btn-cls').onclick = close; overlay.onclick = close;
    document.getElementById('exp-btn-dl').onclick = () => { startExport({ subject: document.getElementById('exp-subj').checked, marks: document.getElementById('exp-marks').checked, avg: document.getElementById('exp-avg').checked }); };
}
function startExport(settings) {
    const status = document.getElementById('exp-status'); status.innerText = "Анализ...";
    const rows = document.querySelectorAll(SELECTORS.tableRows);
    if (rows.length === 0) { status.innerText = "❌ Таблица не найдена"; return; }
    let csvContent = [], headers = [];
    if (settings.subject) headers.push("Предмет"); if (settings.marks) headers.push("Оценки"); if (settings.avg) headers.push("Средний балл");
    csvContent.push(headers.join(";"));
    let count = 0;
    rows.forEach(row => {
        const rawTexts = row.innerText.split(/[\n\t]+/); let subject = "", marks = [], avg = "";
        rawTexts.forEach(txt => {
            txt = txt.trim(); if (!txt || /^\d{2}\.\d{2}$/.test(txt)) return;
            if (/^[2-5][.,]\d{2}$/.test(txt)) avg = txt.replace('.', ',');
            else if (/^[1-5]$/.test(txt) || ['н','п'].includes(txt.toLowerCase())) marks.push(txt);
            else if (txt.length > 3 && !/\d/.test(txt) && !subject) subject = txt;
        });
        if (subject || marks.length > 0) {
            let rowData = [];
            if (settings.subject) rowData.push(`"${subject}"`); if (settings.marks) rowData.push(`"${marks.join(' ')}"`); if (settings.avg) rowData.push(avg);
            csvContent.push(rowData.join(";")); count++;
        }
    });
    if (count === 0) { status.innerText = "❌ Нет данных"; return; }
    const blob = new Blob(["\uFEFF" + csvContent.join("\r\n")], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `MESH_Grades_${new Date().toLocaleDateString()}.csv`;
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
    status.innerText = `✅ Скачано: ${count}`; setTimeout(() => { document.getElementById('mesh-export-modal').remove(); document.getElementById('mesh-export-overlay').remove(); }, 2000);
}
function injectStyle(id, content) { let style = document.getElementById(id); if (!style) { style = document.createElement('style'); style.id = id; document.head.appendChild(style); } style.innerHTML = content; }