document.addEventListener('DOMContentLoaded', () => {
    const els = {
        // Чекбоксы
        batchClick: document.getElementById('batchClick'),
        formSaver: document.getElementById('formSaver'),
        duplicateFinder: document.getElementById('duplicateFinder'),
        antiLogout: document.getElementById('antiLogout'),
        disableAnimations: document.getElementById('disableAnimations'),
        hideAds: document.getElementById('hideAds'),
        highlightGrades: document.getElementById('highlightGrades'),
        highlightStudent: document.getElementById('highlightStudent'),
        
        // UI
        rulesList: document.getElementById('rulesList'),
        rulesCard: document.getElementById('rulesCard'),
        status: document.getElementById('status'),
        saveBtn: document.getElementById('saveBtn'),
        pickBtn: document.getElementById('pickBtn'),
        exportMenuBtn: document.getElementById('exportMenuBtn')
    };

    // 1. ЗАГРУЗКА
    chrome.storage.sync.get(null, (data) => {
        els.batchClick.checked = data.batchClick || false;
        els.formSaver.checked = data.formSaver || false;
        els.duplicateFinder.checked = data.duplicateFinder || false;
        els.antiLogout.checked = data.antiLogout || false;
        els.disableAnimations.checked = data.disableAnimations || false;
        els.hideAds.checked = data.hideAds || false;
        els.highlightGrades.checked = data.highlightGrades || false;
        els.highlightStudent.checked = data.highlightStudent || false;
        
        renderRules(data.customRules || []);
    });

    // 2. СОХРАНЕНИЕ
    els.saveBtn.addEventListener('click', () => {
        const settings = {
            batchClick: els.batchClick.checked,
            formSaver: els.formSaver.checked,
            duplicateFinder: els.duplicateFinder.checked,
            antiLogout: els.antiLogout.checked,
            disableAnimations: els.disableAnimations.checked,
            hideAds: els.hideAds.checked,
            highlightGrades: els.highlightGrades.checked,
            highlightStudent: els.highlightStudent.checked
        };
        chrome.storage.sync.set(settings, () => {
            els.status.innerText = 'Сохранено!';
            setTimeout(() => els.status.innerText = '', 1500);
            sendMessage({ action: "updateSettings", settings: settings });
        });
    });

    // 3. КНОПКИ
    els.pickBtn.addEventListener('click', () => { sendMessage({ action: "startPicking" }); window.close(); });
    els.exportMenuBtn.addEventListener('click', () => { sendMessage({ action: "openExportMenu" }); window.close(); });

    // УТИЛИТЫ
    function sendMessage(msg) {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, msg).catch(()=>{});
        });
    }

    function renderRules(rules) {
        els.rulesList.innerHTML = '';
        if (!rules || rules.length === 0) { els.rulesCard.style.display = 'none'; return; }
        els.rulesCard.style.display = 'block';

        rules.forEach((rule, idx) => {
            const li = document.createElement('li');
            li.className = 'rule-item';
            
            let badge = rule.action === 'hide' 
                ? '<span class="badge" style="background:#95a5a6">СКРЫТ</span>' 
                : `<span class="badge" style="background:${rule.value}">ЦВЕТ</span>`;
            
            let name = rule.selector.split('.').pop() || rule.selector;
            if (name.length > 20) name = name.substring(0, 20) + '...';

            li.innerHTML = `<div>${badge} <span title="${rule.selector}">${name}</span></div><span class="del-btn" data-idx="${idx}">×</span>`;
            els.rulesList.appendChild(li);
        });

        document.querySelectorAll('.del-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = e.target.getAttribute('data-idx');
                rules.splice(index, 1);
                chrome.storage.sync.set({customRules: rules}, () => {
                    renderRules(rules);
                    sendMessage({ action: "refreshRules", rules: rules });
                });
            });
        });
    }
});