(function () {
    if (window.__MESH_HOOKED__) return;
    window.__MESH_HOOKED__ = true;

    let db = { ids: {}, names: {} };

    try {
        const stored = window.localStorage.getItem('MESH_PROFILES_FINAL');
        if (stored) {
            const parsed = JSON.parse(stored);
            if (parsed.ids) db.ids = parsed.ids;
            if (parsed.names) db.names = parsed.names;
        }
    } catch (e) { }

    function saveDb() {
        try { window.localStorage.setItem('MESH_PROFILES_FINAL', JSON.stringify(db)); } catch (e) { }
    }

    function scanData(obj, depth = 0) {
        if (depth > 15 || !obj || typeof obj !== 'object') return;
        if (Array.isArray(obj)) { obj.forEach(o => scanData(o, depth + 1)); return; }

        let pId = obj.student_profile_id || obj.profile_id;
        if (pId) {
            ['id', 'person_id', 'student_id', 'user_id'].forEach(k => {
                if (obj[k]) db.ids[obj[k].toString()] = pId.toString();
            });
            let name = obj.last_name || obj.lastName || obj.surname;
            if (name) {
                let cleanName = name.toLowerCase().replace(/[^а-яё]/g, '');
                db.names[cleanName] = pId.toString();
            }
            saveDb();
        }
        for (let k in obj) { if (obj.hasOwnProperty(k)) scanData(obj[k], depth + 1); }
    }

    const _fetch = window.fetch;
    window.fetch = async function (...args) {
        // SPY LOGIC: Capture manual grade requests
        try {
            const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
            const options = args[1] || {};
            if (url.includes('/marks') && (options.method === 'POST' || options.method === 'PUT')) {
                console.log("🕵️ MESH Spy: Caught /marks request!", options);
                window.postMessage({
                    type: 'MESH_DEBUG_SPY',
                    url: url,
                    headers: options.headers,
                    body: options.body
                }, '*');
            }
        } catch (e) { console.error("Spy Error:", e); }

        const res = await _fetch.apply(this, args);
        try {
            const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
            if (url.includes('/api/')) {
                res.clone().json().then(data => {
                    scanData(data);
                    window.postMessage({ type: 'MESH_DB_UPDATE', db: db }, '*');
                }).catch(e => { });
            }
        } catch (e) { }
        return res;
    };
    console.log("🔥 MESH Interceptor V75 Deployed.");
})();